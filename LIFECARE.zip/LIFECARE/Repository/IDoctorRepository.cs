﻿using LIFECARE.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LIFECARE.Repository
{
    public interface IDoctorRepository
    {
        Task<Role> GetRoleByUsernamePasswordAsync(string username, string password);
        Task<int?> GetDoctorIdByRoleAndUsernameAsync(string roleName, string username);
        Task<IEnumerable<Appointment>> GetAppointmentsByDoctorIdAsync(int doctorId);
        Task<int?> GetStaffIdByDoctorIdAsync(int doctorId);
        Task InsertPrescriptionAsync(MainPrescription prescription);


    }
}
