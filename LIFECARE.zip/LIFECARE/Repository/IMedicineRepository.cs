﻿using LIFECARE.Models;

namespace LIFECARE.Repository
{
    public interface IMedicineRepository
    {
        Task<int?> GetMedicineIdByNameAsync(string medicineName);
        Task AddMedicinePrescriptionAsync(int appointmentId, int medicineId, int quantity, string dosage, string duration, string frequency, bool isMedicineStatus, int createdBy);
        Task<IEnumerable<MedicineInfo>> GetAllMedicinesAsync(); // New method to get all medicines
    }
}
