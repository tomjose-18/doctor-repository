﻿using LIFECARE.Models;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace LIFECARE.Repository
{
    public class TestRepository : ITestRepository
    {
        private readonly string _connectionString;

        public TestRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("ConnectionMVCWin");
        }

        public async Task AddTestPrescriptionAsync(int appointmentId, string testName, string testResult, bool isStatus, int createdBy)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand("InsertTestPrescription", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@AppointmentId", appointmentId);
                    command.Parameters.AddWithValue("@TestName", testName); // Added TestName parameter
                    command.Parameters.AddWithValue("@TestResult", testResult); // Added TestResult parameter
                    command.Parameters.AddWithValue("@IsStatus", isStatus);
                    command.Parameters.AddWithValue("@CreatedBy", createdBy);

                    await command.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<IEnumerable<TestInfo>> GetAllTestsAsync()
        {
            var tests = new List<TestInfo>();

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand("SELECT * FROM TestInfo", connection))
                {
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            tests.Add(new TestInfo
                            {
                                TestId = reader.GetInt32(reader.GetOrdinal("TestId")),
                                TestName = reader.GetString(reader.GetOrdinal("TestName")),
                                TestType = reader.GetString(reader.GetOrdinal("TestType")),
                                Category = reader.GetString(reader.GetOrdinal("Category")),
                                Amount = reader.GetDecimal(reader.GetOrdinal("Amount")),
                                ReferenceMaxRange = reader.GetString(reader.GetOrdinal("ReferenceMaxRange")),
                                SampleRequired = reader.GetString(reader.GetOrdinal("SampleRequired")),
                                CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                                CreatedBy = reader.GetInt32(reader.GetOrdinal("CreatedBy"))
                            });
                        }
                    }
                }
            }

            return tests;
        }

        public async Task<int?> GetTestIdByNameAsync(string testName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand("sp_GetTestIdByName", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TestName", testName);

                    var result = await command.ExecuteScalarAsync();
                    return result != null ? (int?)result : null;
                }
            }
        }
    }
}
