﻿namespace LIFECARE.Models
{
    public class PatientDetailsViewModel
    {
        public string PatientName { get; set; }
        public string Gender { get; set; }
        public string BloodGroup { get; set; }
        public DateTime AppointmentDate { get; set; }
    }
}
