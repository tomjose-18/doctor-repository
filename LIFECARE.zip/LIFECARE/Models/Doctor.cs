﻿namespace LIFECARE.Models
{
	public class Doctor
	{
		public int DoctorId { get; set; }
		public int StaffId { get; set; }
		public decimal ConsultationFee { get; set; }
		public int SpecializationId { get; set; }
	}
}
