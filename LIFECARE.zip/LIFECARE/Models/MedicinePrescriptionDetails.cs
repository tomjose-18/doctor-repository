﻿namespace LIFECARE.Models
{
	public class MedicinePrescriptionDetails
	{
		public int MedicinePrescriptionDetailsId { get; set; }
		public int MedicinePrescriptionId { get; set; }
		public int MedicineId { get; set; }
		public int Quantity { get; set; }
		public string Dosage { get; set; }
		public string Duration { get; set; }
		public string Frequency { get; set; }

		// Navigation properties
		public MedicinePrescription MedicinePrescription { get; set; }
		public MedicineInfo Medicine { get; set; }
	}
}
