﻿using LIFECARE.Models;

namespace LIFECARE.Service
{
    public interface ILoginService
    {
        Task<Role> GetRoleByUsernamePasswordAsync(string username, string password);
    }
}
