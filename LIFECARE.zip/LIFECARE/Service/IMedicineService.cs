﻿namespace LIFECARE.Service
{
    public interface IMedicineService
    {
        Task<int?> GetMedicineIdByNameAsync(string medicineName);
        Task AddMedicinePrescriptionAsync(int appointmentId, int medicineId, int quantity, string dosage, string duration, string frequency, bool isMedicineStatus, int createdBy);
    }
}
